// API version 2
var express = require('express');
var router = express.Router();
var path = require('path');

router.get('*', function(request, response) {
    response.status(200);
    response.json({
        "description": "Recipes REST server API version 2 is no longer supported. Please use API version 1."
    });
});

module.exports = router;
